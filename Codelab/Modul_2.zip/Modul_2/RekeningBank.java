// Deklarasi kelas RekeningBank untuk merepresentasikan rekening bank
public class RekeningBank {
    // Deklarasi variabel instance private untuk menyimpan nomor rekening
    private String nomorRekening;
    // Deklarasi variabel instance private untuk menyimpan nama pemilik rekening
    private String namaPemilik;
    // Deklarasi variabel instance private untuk menyimpan saldo rekening
    private double saldo;

    // Konstruktor kelas RekeningBank dengan tiga parameter
    public RekeningBank(String nomorRekening, String namaPemilik, double saldo) {
        // Menginisialisasi variabel instance nomorRekening dengan nilai parameter
        this.nomorRekening = nomorRekening;
        // Menginisialisasi variabel instance namaPemilik dengan nilai parameter
        this.namaPemilik = namaPemilik;
        // Menginisialisasi variabel instance saldo dengan nilai parameter
        this.saldo = saldo;
    }

    // Metode untuk menampilkan informasi rekening
    public void tampilkanInfo() {
        // Mencetak nomor rekening ke konsol
        System.out.println("Nomor Rekening: " + nomorRekening);
        // Mencetak nama pemilik rekening ke konsol
        System.out.println("Nama Pemilik: " + namaPemilik);
        // Mencetak saldo rekening ke konsol
        System.out.println("Saldo: Rp" + saldo);
    }

    // Metode untuk menyetor uang ke rekening
    public void setorUang(double jumlah) {
        // Menambahkan jumlah setoran ke saldo saat ini
        saldo += jumlah;
        // Mencetak konfirmasi setoran dan saldo terbaru ke konsol
        System.out.println(namaPemilik + " menyetor Rp" + jumlah + ". Saldo sekarang: Rp" + saldo);
    }

    // Metode untuk menarik uang dari rekening
    public void tarikUang(double jumlah) {
        // Memeriksa apakah saldo mencukupi untuk penarikan
        if (saldo >= jumlah) {
            // Jika saldo mencukupi, kurangi saldo dengan jumlah penarikan
            saldo -= jumlah;
            // Mencetak konfirmasi penarikan berhasil dan saldo terbaru ke konsol
            System.out.println(namaPemilik + " menarik Rp" + jumlah + ". (Berhasil) Saldo sekarang: Rp" + saldo);
        } else {
            // Jika saldo tidak mencukupi, cetak pesan penarikan gagal dan saldo saat ini
            System.out.println(namaPemilik + " menarik Rp" + jumlah + ". (Gagal, Saldo tidak mencukupi) Saldo saat ini: Rp" + saldo);
        }
    }
} // Akhir dari deklarasi kelas RekeningBank