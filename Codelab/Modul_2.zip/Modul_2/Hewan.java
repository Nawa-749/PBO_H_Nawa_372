// Deklarasi kelas Hewan
public class Hewan {
    // Deklarasi variabel instance untuk menyimpan nama hewan
    String Nama;
    // Deklarasi variabel instance untuk menyimpan jenis hewan
    String Jenis;
    // Deklarasi variabel instance untuk menyimpan suara hewan
    String Suara;

    // Metode untuk menampilkan informasi tentang hewan
    public void tampilkanInfo() {
        // Mencetak nama hewan ke konsol
        System.out.println("Nama: " + Nama);
        // Mencetak jenis hewan ke konsol
        System.out.println("Jenis: " + Jenis);
        // Mencetak suara hewan ke konsol
        System.out.println("Suara: " + Suara);
    }
} // Akhir dari deklarasi kelas Hewan