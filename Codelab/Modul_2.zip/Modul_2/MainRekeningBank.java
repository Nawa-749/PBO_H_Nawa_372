// Deklarasi kelas MainRekeningBank untuk menjalankan program perbankan
public class MainRekeningBank {
    // Metode main sebagai titik awal eksekusi program
    public static void main(String[] args) {
        // Membuat objek rekening1 dari kelas RekeningBank dengan nomor rekening, nama pemilik, dan saldo awal
        RekeningBank rekening1 = new RekeningBank("202410370110372", "Nawa", 10000000.0);

        // Membuat objek rekening2 dari kelas RekeningBank dengan nomor rekening, nama pemilik, dan saldo awal
        RekeningBank rekening2 = new RekeningBank("202410370110368", "Alfina", 5000000.0);

        // Memanggil metode tampilkanInfo() untuk menampilkan informasi rekening1
        rekening1.tampilkanInfo();
        // Mencetak baris kosong untuk memisahkan output
        System.out.println();
        // Memanggil metode tampilkanInfo() untuk menampilkan informasi rekening2
        rekening2.tampilkanInfo();
        // Mencetak baris kosong untuk memisahkan output
        System.out.println();

        // Memanggil metode setorUang() untuk menambah saldo rekening1 sebesar 2.000.000
        rekening1.setorUang(2000000.0);
        // Memanggil metode setorUang() untuk menambah saldo rekening2 sebesar 500.000
        rekening2.setorUang(500000.0);
        // Mencetak baris kosong untuk memisahkan output
        System.out.println();

        // Memanggil metode tarikUang() untuk mengurangi saldo rekening1 sebesar 8.000.000
        rekening1.tarikUang(8000000.0);
        // Memanggil metode tarikUang() untuk mengurangi saldo rekening2 sebesar 300.000
        rekening2.tarikUang(300000.0);
        // Mencetak baris kosong untuk memisahkan output
        System.out.println();

        // Memanggil metode tampilkanInfo() untuk menampilkan informasi terbaru rekening1
        rekening1.tampilkanInfo();
        // Mencetak baris kosong untuk memisahkan output
        System.out.println();
        // Memanggil metode tampilkanInfo() untuk menampilkan informasi terbaru rekening2
        rekening2.tampilkanInfo();
    }
} // Akhir dari deklarasi kelas MainRekeningBank