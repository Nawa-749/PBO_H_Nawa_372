// Deklarasi kelas MainHewan untuk menjalankan program
public class MainHewan {
    // Metode main sebagai titik awal eksekusi program
    public static void main(String[] args) {
        // Membuat objek hewan1 dari kelas Hewan
        Hewan hewan1 = new Hewan();
        // Membuat objek hewan2 dari kelas Hewan
        Hewan hewan2 = new Hewan();

        // Mengatur nilai atribut Nama untuk objek hewan1
        hewan1.Nama = "Kucing";
        // Mengatur nilai atribut Jenis untuk objek hewan1
        hewan1.Jenis = "Mamalia";
        // Mengatur nilai atribut Suara untuk objek hewan1
        hewan1.Suara = "Nyann~~";

        // Mengatur nilai atribut Nama untuk objek hewan2
        hewan2.Nama = "Anjing";
        // Mengatur nilai atribut Jenis untuk objek hewan2
        hewan2.Jenis = "Mamalia";
        // Mengatur nilai atribut Suara untuk objek hewan2
        hewan2.Suara = "Woof-Woof!!";

        // Memanggil metode tampilkanInfo() untuk menampilkan informasi hewan1
        hewan1.tampilkanInfo();
        // Mencetak baris kosong untuk memisahkan output
        System.out.println();
        // Memanggil metode tampilkanInfo() untuk menampilkan informasi hewan2
        hewan2.tampilkanInfo();
    }
} // Akhir dari deklarasi kelas MainHewan